# AR Character Camera (v1)
Web app: front camera + MediaPipe Face Landmarker drives a 3D head (52 ARKit blendshapes + head pose) over your face. Record to mp4/webm.

Run: `cd /workspace/ar-character-app && python3 -m http.server 8765` → http://localhost:8765
Phones need HTTPS for the camera: host the folder on GitHub Pages, Netlify, or Vercel (static, no build).

- Sample head: `models/facecap.glb` (three.js examples, by Bannaflak, CC-BY 4.0).
- "Load your own character": a .glb with ARKit-named morph targets (eyeBlinkLeft, jawOpen, eyeBlink_L, ...). Matching ignores case and common prefixes/suffixes. A model with no matching morph targets only follows head movement.
- "Hide me" swaps the camera feed for a dark background. Recording includes the mic when it's allowed.
- Libraries (three.js 0.160, tasks-vision 0.10.14, face model) load from CDN, so you need to be online.

## Built-in characters
Pick a character from the dropdown, or open `?char=sully` to start with Sully.
- `characters/sully.glb`: Sully Mallard, a full-body Tripo model. The original was 1.9M triangles and a 131 MB OBJ; it's now 56.8k triangles, 1024px WebP textures, meshopt compression, 600 KB.
  It only follows head movement (it has no expressions). The `pivot` and `scale` in `BUILTINS` (app.js) place its head over your face.
- Test the framing without a camera: `?debugpose` puts the character where a face 50 cm away would be.
- Source files: `characters/sully_src/`. Preview render: `characters/sully-preview.png`.
