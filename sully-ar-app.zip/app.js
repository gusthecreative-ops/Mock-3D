import * as THREE from 'three';
import { GLTFLoader } from 'three/addons/loaders/GLTFLoader.js';
import { KTX2Loader } from 'three/addons/loaders/KTX2Loader.js';
import { MeshoptDecoder } from 'three/addons/libs/meshopt_decoder.module.js';
import { FaceLandmarker, FilesetResolver } from 'https://cdn.jsdelivr.net/npm/@mediapipe/tasks-vision@0.10.14/vision_bundle.mjs';

const $ = id => document.getElementById(id);
const video = $('video'), out = $('out'), octx = out.getContext('2d');
const status = t => $('status').textContent = t, note = t => $('note').textContent = t || '';

// three.js offscreen renderer (transparent)
const renderer = new THREE.WebGLRenderer({ alpha: true, antialias: true, preserveDrawingBuffer: true });
renderer.setPixelRatio(1);
const scene = new THREE.Scene();
scene.add(new THREE.HemisphereLight(0xffffff, 0x444466, 2.2));
const dl = new THREE.DirectionalLight(0xffffff, 1.5); dl.position.set(0, 50, 100); scene.add(dl);
// MediaPipe's canonical camera: vertical FOV 63°, units in cm
const camera = new THREE.PerspectiveCamera(63, 1, 1, 10000);
const anchor = new THREE.Object3D(); anchor.matrixAutoUpdate = false; anchor.visible = false; scene.add(anchor);

const ktx2 = new KTX2Loader().setTranscoderPath('https://cdn.jsdelivr.net/npm/three@0.160.0/examples/jsm/libs/basis/').detectSupport(renderer);
const loader = new GLTFLoader().setKTX2Loader(ktx2).setMeshoptDecoder(MeshoptDecoder);

let character = null, morphMeshes = [];
const norm = s => s.toLowerCase().replace(/^.*[.:|]/, '').replace(/^(blendshape\d*_?|arkit_?|bs_?|shape_?)/, '').replace(/[_\s.-]?(l|left)$/i,'left').replace(/[_\s.-]?(r|right)$/i,'right').replace(/[_\s-]/g, '');

function setCharacter(root, cfg = {}) {
  if (character) anchor.remove(character);
  root.traverse(o => { if (o.isMesh) {
    if (!o.geometry.attributes.normal) o.geometry.computeVertexNormals();
    if (cfg.fixMaterial) { o.material.normalMap = null; o.material.metalness = 0; o.material.needsUpdate = true; }
  }});
  // normalize: fit to ~20cm tall centered on origin, or use a per-character head pivot (full-body models)
  const box = new THREE.Box3().setFromObject(root), size = box.getSize(new THREE.Vector3());
  const c = cfg.pivot ? new THREE.Vector3(...cfg.pivot) : box.getCenter(new THREE.Vector3());
  const s = cfg.scale || 20 / Math.max(size.y, size.x, 1e-6);
  const wrap = new THREE.Group(); root.position.sub(c); wrap.add(root); wrap.scale.setScalar(s);
  character = wrap; anchor.add(wrap);
  morphMeshes = [];
  const matched = new Set();
  root.traverse(o => { if (o.isMesh && o.morphTargetDictionary) {
    const map = {}; for (const [k, i] of Object.entries(o.morphTargetDictionary)) map[norm(k)] = i;
    morphMeshes.push({ mesh: o, map });
    ARKIT.forEach(n => { if (map[norm(n)] !== undefined) matched.add(n); });
  }});
  note(matched.size ? (matched.size < 52 ? `${matched.size}/52 expressions matched` : '') :
    'No facial expressions on this model (needs face rigging). It will follow your head movement only.');
}
const ARKIT = ['browDownLeft','browDownRight','browInnerUp','browOuterUpLeft','browOuterUpRight','cheekPuff','cheekSquintLeft','cheekSquintRight','eyeBlinkLeft','eyeBlinkRight','eyeLookDownLeft','eyeLookDownRight','eyeLookInLeft','eyeLookInRight','eyeLookOutLeft','eyeLookOutRight','eyeLookUpLeft','eyeLookUpRight','eyeSquintLeft','eyeSquintRight','eyeWideLeft','eyeWideRight','jawForward','jawLeft','jawOpen','jawRight','mouthClose','mouthDimpleLeft','mouthDimpleRight','mouthFrownLeft','mouthFrownRight','mouthFunnel','mouthLeft','mouthLowerDownLeft','mouthLowerDownRight','mouthPressLeft','mouthPressRight','mouthPucker','mouthRight','mouthRollLower','mouthRollUpper','mouthShrugLower','mouthShrugUpper','mouthSmileLeft','mouthSmileRight','mouthStretchLeft','mouthStretchRight','mouthUpperUpLeft','mouthUpperUpRight','noseSneerLeft','noseSneerRight','tongueOut'];

// Built-in characters. Full-body models: pivot = head center in model units, scale = model units -> cm.
const BUILTINS = {
  facecap: { name: 'Sample head (expressions)', url: 'models/facecap.glb' },
  sully: { name: 'Sully Mallard (head follow)', url: 'characters/sully.glb', pivot: [0, 0.80, 0.0], scale: 115, fixMaterial: true },
};
const sel = $('charSel');
for (const [k, v] of Object.entries(BUILTINS)) sel.add(new Option(v.name, k));
function loadBuiltin(k) {
  const cfg = BUILTINS[k]; status('Loading ' + cfg.name + '…');
  loader.load(cfg.url, g => { setCharacter(g.scene, cfg); window.__modelLoaded = k; status(video.srcObject ? '' : 'Tap "Start camera"'); },
    undefined, e => status('Model load error: ' + e.message));
}
sel.onchange = () => loadBuiltin(sel.value);
loadBuiltin(new URLSearchParams(location.search).get('char') || 'facecap');
sel.value = new URLSearchParams(location.search).get('char') || 'facecap';

$('file').onchange = e => {
  const f = e.target.files[0]; if (!f) return;
  const url = URL.createObjectURL(f);
  loader.load(url, g => { setCharacter(g.scene); status('Loaded ' + f.name); }, undefined, err => status('Could not load: ' + err.message));
};

let landmarker;
async function initLandmarker() {
  const fs = await FilesetResolver.forVisionTasks('https://cdn.jsdelivr.net/npm/@mediapipe/tasks-vision@0.10.14/wasm');
  landmarker = await FaceLandmarker.createFromOptions(fs, {
    baseOptions: { modelAssetPath: 'https://storage.googleapis.com/mediapipe-models/face_landmarker/face_landmarker/float16/1/face_landmarker.task', delegate: 'GPU' },
    runningMode: 'VIDEO', numFaces: 1, outputFaceBlendshapes: true, outputFacialTransformationMatrixes: true });
}

let showCam = true;
$('toggleCam').onclick = () => { showCam = !showCam; $('toggleCam').textContent = showCam ? 'Hide me' : 'Show me'; };

$('start').onclick = async () => {
  try {
    status('Starting camera…');
    const stream = await navigator.mediaDevices.getUserMedia({ video: { facingMode: 'user', width: { ideal: 1280 }, height: { ideal: 720 } }, audio: false });
    video.srcObject = stream; await video.play();
    micStream = await navigator.mediaDevices.getUserMedia({ audio: true }).catch(() => null);
    status('Loading face tracker…'); await initLandmarker();
    $('start').style.display = 'none'; $('rec').disabled = false; status('');
    requestAnimationFrame(loop);
  } catch (e) { status('Camera error: ' + e.message + (location.protocol !== 'https:' && location.hostname !== 'localhost' ? ' (camera needs HTTPS)' : '')); }
};

const DEBUG_POSE = new URLSearchParams(location.search).has('debugpose'); // test: fake face 50cm in front
let lastT = -1, lastSeen = 0;
function loop() {
  const w = video.videoWidth, h = video.videoHeight;
  if (w && (out.width !== w || out.height !== h)) { out.width = w; out.height = h; renderer.setSize(w, h, false); camera.aspect = w / h; camera.updateProjectionMatrix(); }
  if (w && video.currentTime !== lastT) {
    lastT = video.currentTime;
    const r = landmarker.detectForVideo(video, performance.now());
    if (r.facialTransformationMatrixes?.length) {
      anchor.matrix.fromArray(r.facialTransformationMatrixes[0].data); anchor.visible = true; lastSeen = performance.now();
      const cats = r.faceBlendshapes[0].categories;
      for (const { mesh, map } of morphMeshes) for (const c of cats) { const i = map[norm(c.categoryName)]; if (i !== undefined) mesh.morphTargetInfluences[i] = c.score; }
    } else if (DEBUG_POSE) { anchor.matrix.makeTranslation(0, 0, -50); anchor.visible = true; }
    else if (performance.now() - lastSeen > 300) anchor.visible = false;
  }
  renderer.render(scene, camera);
  // composite mirrored (selfie view) into output canvas — this is what gets recorded
  octx.save(); octx.setTransform(-1, 0, 0, 1, out.width, 0);
  if (showCam) octx.drawImage(video, 0, 0, out.width, out.height); else { octx.fillStyle = '#111'; octx.fillRect(0, 0, out.width, out.height); }
  octx.drawImage(renderer.domElement, 0, 0, out.width, out.height);
  octx.restore();
  requestAnimationFrame(loop);
}

// Recording
let rec, chunks = [], micStream = null;
$('rec').onclick = () => {
  if (rec && rec.state === 'recording') { rec.stop(); return; }
  const stream = out.captureStream(30);
  micStream?.getAudioTracks().forEach(t => stream.addTrack(t));
  const types = ['video/mp4;codecs=avc1', 'video/mp4', 'video/webm;codecs=vp9,opus', 'video/webm'];
  const mimeType = types.find(t => MediaRecorder.isTypeSupported(t)) || '';
  rec = new MediaRecorder(stream, mimeType ? { mimeType } : {}); chunks = [];
  rec.ondataavailable = e => e.data.size && chunks.push(e.data);
  rec.onstop = () => {
    const type = rec.mimeType || 'video/webm', ext = type.includes('mp4') ? 'mp4' : 'webm';
    const a = document.createElement('a'); a.href = URL.createObjectURL(new Blob(chunks, { type }));
    a.download = `character-${Date.now()}.${ext}`; a.click();
    $('rec').classList.remove('on'); $('rec').textContent = '● Record';
  };
  rec.start(250); $('rec').classList.add('on'); $('rec').textContent = '■ Stop';
};
